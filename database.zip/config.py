class config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///database/revenda.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SALT = "X#3jfk$%kKmGw&*jKLiPW@!jm345"
    JWT_SECRET_KEY = 'hjsdfhj#$@DFhsms@%ldkPç()H#Dnx3@'
    JWT_BLACKLIST_ENABLED = True